package com.smallworld;

import com.smallworld.data.Transaction;
import org.junit.Test;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import static org.junit.Assert.assertEquals;

public class TransactionDataFetcherTest {

    @Test
    public void testTotalTransactionAmount() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        Double actual = td.getTotalTransactionAmount();
        Double expected = 2889.17;
        assertEquals(expected,actual);

    }

    @Test
    public void testTotalTransactionAmountSentBy() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        Double actual = td.getTotalTransactionAmountSentBy("Tom Shelby");
        Double expected = 678.06;
        assertEquals(expected,actual);

    }

    @Test
    public void testMaxTransactionAmount() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        Double actual = td.getMaxTransactionAmount();
        Double expected = 985.0;
        assertEquals(expected,actual);

    }

    @Test
    public void testCountUniqueClients() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        long actual = td.countUniqueClients();
        long expected = 10;
        assertEquals(expected,actual);

    }

    @Test
    public void testOpenComplianceIssues() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        Boolean actual = td.hasOpenComplianceIssues("Tom Shelby");
        Boolean expected = true;
        assertEquals(expected,actual);

    }

    @Test
    public void testTransactionsByBeneficiaryName() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        Map<String, Transaction> actual = td.getTransactionsByBeneficiaryName();
        String expected = TestUtils.getMockTransactionsByBeneficiaryName();
        assertEquals(expected,actual.toString());

    }

    @Test
    public void testUnsolvedIssueIds() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        Set<Integer> actual = td.getUnsolvedIssueIds();
        Set<Integer> expected = TestUtils.getMockUnsolvedIssueIds();
        assertEquals(expected,actual);

    }

    @Test
    public void testAllSolvedIssueMessages() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        List<String> actual = td.getAllSolvedIssueMessages();
        List<String> expected = TestUtils.getMockSolvedIssueMessages();
        assertEquals(expected,actual);

    }

    @Test
    public void testTop3TransactionsByAmount() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        List<Transaction> actual = td.getTop3TransactionsByAmount();
        List<Transaction> expected = TestUtils.getMockTop3Transactions();
        assertEquals(expected,actual);

    }

    @Test
    public void testTopSender() {

        TransactionDataFetcher td = new TransactionDataFetcher();
        Optional<String> actual = td.getTopSender();
        Optional<String> expected = Optional.of("Arthur Shelby");
        assertEquals(expected,actual);

    }

}
